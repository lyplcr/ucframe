#ifndef __CHARGEN_H__
#define __CHARGEN_H__

#include "lwip/opt.h"

#if LWIP_SOCKET

void chargen_init(void);

#endif /* LWIP_SOCKET */


#endif /* __CHARGEN_H__ */
