#ifndef BENCH_H
#define BENCH_H

#include "cryptlib.h"

void BenchMarkAll(float t=1.0);

#endif
